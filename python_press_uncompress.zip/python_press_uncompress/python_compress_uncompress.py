#!usr/bin/python3
# coding:utf-8
import os
import zipfile
import gzip
import bz2
import lzma
import tarfile

import shutil

import rarfile
import py7zr

from py7zr.py7zr import pack_7zarchive, unpack_7zarchive

# shutil register 7zip
shutil.register_archive_format('7zip',
                               pack_7zarchive,
                               description='7zip archive')

shutil.register_unpack_format('7zip',
                              ['.7z'],
                              unpack_7zarchive,
                              description='7zip archive')

"""
.gz .tar  .tgz .zip .rar

gz： 即gzip，通常只能压缩一个文件。与tar结合起来就可以实现先打包，再压缩。

tar： linux系统下的打包工具，只打包，不压缩

tgz：即tar.gz。先用tar打包，然后再用gz压缩得到的文件

zip： 不同于gzip，虽然使用相似的算法，可以打包压缩多个文件，不过分别压缩文件，压缩率低于tar。

rar：打包压缩文件，最初用于DOS，基于window操作系统。压缩率比zip高，但速度慢，随机访问的速度也慢。


"""


# --------------------------------.xz-----------------------------
def xz_path(compress_path, dst_file, buffering=8096):
    """

    :param compress_path:
    :param dst_file:
    :param buffering:
    :return:
    """
    with open(file=compress_path, mode="rb", buffering=buffering) as content_handler:
        with lzma.open(filename=dst_file, mode="wb") as f:
            f.write(content_handler.read())


def unxz_file(xz_file, dst_file, buffering=8096):
    """

    :param xz_file:
    :param dst_file:
    :param buffering:
    :return:
    """
    with lzma.open(xz_file) as src_handler:
        with open(file=dst_file, mode="wb", buffering=buffering) as target_handler:
            target_handler.write(src_handler.read())


# --------------------------------.xz-----------------------------
# --------------------------------.gz-----------------------------
def gzip_path(compress_path, dst_file, buffering=8096, compresslevel=1):
    """

    :param compress_path:
    :param dst_file:
    :param buffering:
    :param compresslevel: 1~9
    :return:
    """
    with open(file=compress_path, mode="rb", buffering=buffering) as content_handler:
        with gzip.open(filename=dst_file, mode="wb", compresslevel=compresslevel) as f:
            f.write(content_handler.read())


def ungzip_file(gzip_file, dst_file, buffering=8096):
    """

    :param gzip_file:
    :param dst_file:
    :param buffering:
    :return:
    """

    with gzip.GzipFile(gzip_file) as src_handler:
        with open(file=dst_file, mode="wb", buffering=buffering) as target_handler:
            target_handler.write(src_handler.read())


# --------------------------------.gz-----------------------------
# --------------------------------.bz-----------------------------
def bz_path(compress_path, dst_file, buffering=8096, compresslevel=3):
    """

    :param compresslevel:
    :param compress_path:
    :param dst_file:
    :param buffering:
    :return:
    """
    with open(file=compress_path, mode="rb", buffering=buffering) as content_handler:
        with bz2.open(filename=dst_file, mode="wb", compresslevel=compresslevel) as f:
            f.write(content_handler.read())


def unbz_file(bz_file, dst_file, buffering=8096):
    """

    :param bz_file:
    :param dst_file:
    :param buffering:
    :return:
    """
    with bz2.open(bz_file) as src_handler:
        with open(file=dst_file, mode="wb", buffering=buffering) as target_handler:
            target_handler.write(src_handler.read())


# --------------------------------.bz-----------------------------

# --------------------------------zip-----------------------------
def zip_path(compress_path, dst_file, compression=zipfile.ZIP_DEFLATED, compresslevel=3):
    """
    zip dir or file

    compress_path:
    dst_file:
    compression: ZIP_STORED (no compression), ZIP_DEFLATED (requires zlib),
                 ZIP_BZIP2 (requires bz2) or ZIP_LZMA (requires lzma).
    compresslevel: None (default for the given compression type) or an integer
                   specifying the level to pass to the compressor.
                   When using ZIP_STORED or ZIP_LZMA this keyword has no effect.
                   When using ZIP_DEFLATED integers 0 through 9 are accepted.
                   When using ZIP_BZIP2 integers 1 through 9 are accepted.
    """
    with zipfile.ZipFile(file=dst_file, mode='w', compression=compression,
                         compresslevel=compresslevel) as zip_handle:
        if os.path.isfile(compress_path) or os.path.islink(compress_path):
            zip_handle.write(compress_path)

        elif os.path.isdir(compress_path):
            for path, dirnames, filenames in os.walk(compress_path):
                fpath = path.replace(compress_path, '')
                for filename in filenames:
                    zip_handle.write(os.path.join(path, filename), os.path.join(fpath, filename))


def unzip_file(zip_file, dst_dir):
    """

    :param zip_file:
    :param dst_dir:
    :return:
    """

    if zipfile.is_zipfile(zip_file):
        with zipfile.ZipFile(zip_file, 'r') as z:
            for file in z.namelist():
                z.extract(file, dst_dir)
# --------------------------------zip-----------------------------

# --------------------------------.tar-----------------------------
# --------------------------------.tar-----------------------------


def tar_path(compress_path, dst_file, mode="w"):
    """

    :param mode:
    :param compress_path:
    :param dst_file:
    :return:
    """

    with tarfile.open(dst_file, mode=mode) as tar_handler:
        if os.path.isfile(compress_path):
            tar_handler.add(compress_path)

        elif os.path.isdir(compress_path):
            for root, dirnames, files in os.walk(compress_path):
                for file in files:
                    fpath = os.path.join(root, file)
                    tar_handler.add(fpath)


def untar_file(tar_file, dst_dir):
    """
    work not well !!!!!!!
    uncompress a tarfile to destination directory
    :param tar_file:
    :param dst_dir:
    :return:
    """
    if tarfile.is_tarfile(tar_file):
        with tarfile.open(tar_file) as t:
            t.extractall(path=dst_dir)


# --------------------------------.tar-----------------------------
# --------------------------------.rar-----------------------------


def unrar_file(rar_file, dst_dir):
    with rarfile.RarFile(rar_file, 'r') as r:
        r.extractall(dst_dir, r.namelist())
    """
        raise BadRarFile("Failed the read enough data: req=%d got=%d" % (orig, len(data)))
    rarfile.BadRarFile: Failed the read enough data: req=242139 got=52
    
    
    """


# --------------------------------.rar-----------------------------
# --------------------------------.7z-----------------------------


def un7z_file(seven_zip_file, dst_dir, password=None):
    """

    :param seven_zip_file:
    :param dst_dir:
    :param password:
    :return:
    """
    if py7zr.is_7zfile(seven_zip_file):
        with py7zr.SevenZipFile(seven_zip_file, mode='r', password=password) as py_7z:
            py_7z.extractall(dst_dir)


def py7z_file(compress_path, dst_file):
    """

    :param compress_path:
    :param dst_file:
    :return:
    """
    with py7zr.SevenZipFile(dst_file, 'w') as py7z_handler:
        if os.path.isfile(compress_path) or os.path.islink(compress_path):
            py7z_handler.write(compress_path)
        elif os.path.isdir(compress_path):
            py7z_handler.writeall(compress_path)


# --------------------------------.7z-----------------------------

# ------------------------------shutil--------------------------------
# 提供了高级用法
# zip, tar, bztar，gztar, 7zip(注册)
compress_type_list = ["zip", "tar", "bztar", "gztar", "xztar", "7zip"]

# for compress_type in compress_type_list:
#     # compression
#     base_name = "test"
#     compress_name = shutil.make_archive(base_name=base_name, format=compress_type,  root_dir="src_directory")
#     if not compress_name:
#         compress_name = base_name + "." + "7z"
#     # extraction
#     shutil.unpack_archive(filename=compress_name, extract_dir=compress_type)


# ------------------------------shutil--------------------------------




